<!-- header section starts  -->

<section class="header">

   <div class="flex">
      <a href="#home" class="logo">FANCY STAY</a>
      <a href="#availability" class="btn">check availability</a>
      <div id="menu-btn" class="fas fa-bars"></div>
   </div>

   <nav class="navbar">
      <a href="index.php#home">HOME</a>
      <a href="index.php#about">ABOUT</a>
      <a href="index.php#reservation">RESERVATION</a>
      <a href="index.php#gallery">GALLERY</a>
      <a href="index.php#contact">CONTACT</a>
      <a href="index.php#reviews">REVIEW</a>
      <a href="bookings.php">MY BOOKINGS</a>
   </nav>

</section>

<!-- header section ends -->